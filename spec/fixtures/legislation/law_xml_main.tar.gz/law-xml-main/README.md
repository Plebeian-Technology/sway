law-xml fixture
